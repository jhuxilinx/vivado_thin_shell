/**
 * Copyright (C) 2016-2018 Xilinx, Inc
 * Author(s) : Sonal Santan
 *           : Hem Neema
 *           : Ryan Radjabi
 *
 * Copyright (C) 2020 Xilinx, Inc
 * Author(s) : Jiashuai Zhang
 *           : Xiaopeng Song
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may
 * not use this file except in compliance with the License. A copy of the
 * License is located at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

#ifndef _COMMON_H_
#define _COMMON_H_

#include <iostream>
#include <assert.h>

#define FLASH_BASE_ADDRESS 0x00040000
#define micap_BASE_ADDRESS 0x00020000
#define BAR_INDEX "0"

int pcieBarRead(unsigned int pf_bar, unsigned long long offset, void* buffer, unsigned long long length);
int pcieBarWrite(unsigned int pf_bar, unsigned long long offset, const void* buffer, unsigned long long length);
void* wordcopy(void *dst, const void* src, size_t bytes);

#endif
