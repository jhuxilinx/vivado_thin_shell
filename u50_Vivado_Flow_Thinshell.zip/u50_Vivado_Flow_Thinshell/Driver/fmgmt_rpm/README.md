#run
sudo ./install.sh
