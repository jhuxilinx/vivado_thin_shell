#author    : jishuai
#release   : 2020-6-22
#company   : Xilinx

rpm -ivh *.rpm
