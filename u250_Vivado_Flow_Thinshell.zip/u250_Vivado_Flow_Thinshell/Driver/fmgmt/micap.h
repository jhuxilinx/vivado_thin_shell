/**
 * Copyright (C) 2016-2018 Xilinx, Inc
 * Author(s) : Sonal Santan
 *           : Hem Neema
 *           : Ryan Radjabi
 *
 * Copyright (C) 2020 Xilinx, Inc
 * Author(s) : Jiashuai Zhang
 *           : Xiaopeng Song
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may
 * not use this file except in compliance with the License. A copy of the
 * License is located at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

#ifndef micap_H
#define micap_H

#include "icap_fifo.h"
#include <sys/stat.h>
#include <vector>

class micap
{
public:
    micap(const char *f );
    ~micap();
    int ProgramPRbit( const char *prfile);

    static int icapRead(unsigned int pf_bar, unsigned long long offset, void *buffer, unsigned long long length);
    static int icapWrite(unsigned int pf_bar, unsigned long long offset, const void *buffer, unsigned long long length);

private:

    icap_fifo *mXfifo;

    bool mapDevice(const char *f);

    char *mMgmtMap;
    int mFd;
    struct stat mSb;

};

#endif //
