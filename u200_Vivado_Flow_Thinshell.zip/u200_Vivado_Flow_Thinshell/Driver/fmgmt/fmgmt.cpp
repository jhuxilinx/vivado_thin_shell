/**
 * Copyright (C) 2016-2018 Xilinx, Inc
 * Author(s) : Sonal Santan
 *           : Hem Neema
 *           : Ryan Radjabi
 *
 * Copyright (C) 2020 Xilinx, Inc
 * Author(s) : Jiashuai Zhang
 *           : Xiaopeng Song
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may
 * not use this file except in compliance with the License. A copy of the
 * License is located at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

/*
 * fmgmt
 * -flash_prog : flash program over PICe
 * -pr_recfg : PR over PICe
 * -fpga_reload : fpga reboot over PCIe
 * examples,
 * 
 */

#include <iostream>
#include <unistd.h>
#include <getopt.h>
#include <string.h>
#include "mflash.h"
#include "micap.h"

const char* HelpMessage = "xbflash: Incorrect usage. Try 'xbflash [-d device] -m primary_mcs [-n secondary_mcs]'.";

struct T_Arguments_Flash
{
    char *operators = nullptr;
    char *file1 = nullptr;
    char *file2 = nullptr;
    const char *devIdx;
    bool isValid = true;

};

struct T_Arguments_Icap
{
    char *infile = nullptr;
    const char *devIdx;
    bool isValid = true;
};

T_Arguments_Flash parseArguments_Flash( int argc, char *argv[] );
T_Arguments_Icap parseArguments_Icap( int argc, char *argv[] );
int flash_cmd( int argc, char *argv[] );
int icap_cmd( int argc, char *argv[] );

int main( int argc, char *argv[] )
{
    int rev=0;
	
    std::cout <<"fmgmt -- Xilinx FPGA Board MANAGEMENT Utility" << std::endl;
	
    if( getuid() && geteuid() )
    {
        std::cout << "ERROR: fpga board management operation requires root privileges" << std::endl; // todo move this to a header of common messages
        return -EACCES;
    }

    if(argc < 3)
    {
        std::cout <<"fmgmt must have three parameters or more"<< std::endl;
        return -EOF;
    }

    --argc;
    ++argv;

    if ( !strcmp(argv[0], "-flash_prog"))
	   rev = flash_cmd(argc, argv);
    else if ( !strcmp(argv[0], "-pr_recfg"))
           rev = icap_cmd(argc, argv);
    else if ( !strcmp(argv[0], "-fpga_reload"))
           rev = 0;

    return rev;
}


int flash_cmd( int argc, char *argv[] )
{
    std::cout <<"-- Xilinx Board Flash Utility" << std::endl;

    T_Arguments_Flash args = parseArguments_Flash( argc, argv );
    if( !args.isValid )
    {
        std::cout << HelpMessage << std::endl;
        return -1;
    }

    mflash mflash( args.devIdx );
    if( mflash.upgradeFirmware( args.file1, args.file2 ) != 0 )
    {
        std::cout << "XBFlash failed." << std::endl;
        return -1;
    }
    else
    {
        std::cout << "XBFlash completed succesfully. Please reboot device for flash to complete." << std::endl;
        return 0;
    }
}

int icap_cmd( int argc, char *argv[] )
{
    std::cout <<"-- Xilinx Board HWmicap Utility" << std::endl;

    T_Arguments_Icap args = parseArguments_Icap( argc, argv );
    if( !args.isValid )
    {
        std::cout << HelpMessage << std::endl;
        return -1;
    }

    micap icap( args.devIdx );
    if( icap.ProgramPRbit(args.infile) != 0 )
    {
        std::cout << "hwicap failed." << std::endl;
        return -1;
    }
    else
    {
        std::cout << "hwicap completed succesfully. " << std::endl;
        return 0;
    }
}


T_Arguments_Flash parseArguments_Flash( int argc, char *argv[] )
{
    T_Arguments_Flash args;
    int opt;
    if( argc <= 1 )
    {
        args.isValid = false;
    }
    while( ( opt = getopt( argc, argv, "d:m:n:" ) ) != -1 )
    {
        switch( opt )
        {
        case 'd':
            //args.devIdx = atoi( optarg );
	    args.devIdx = optarg;
            break;
        case 'm':
            args.file1 = optarg;
            break;
        case 'n':
            args.file2 = optarg;
            break;
        default:
            std::cout << HelpMessage << std::endl;
            args.isValid = false;
            break;
        }
    }

    if( args.isValid )
    {
        if( args.file1 == nullptr )
        {
            args.isValid = false;
        }
    }

    return args;
}

T_Arguments_Icap parseArguments_Icap( int argc, char *argv[] )
{
    T_Arguments_Icap args;
    int opt;
    if( argc <= 1 )
    {
        args.isValid = false;
    }
    while( ( opt = getopt( argc, argv, "d:f:" ) ) != -1 )
    {
        switch( opt )
        {
        case 'd':
            //args.devIdx = atoi( optarg );
	          args.devIdx = optarg;
            break;
        case 'f':
            args.infile = optarg;
            break;
        default:
            std::cout << HelpMessage << std::endl;
            args.isValid = false;
            break;
        }
    }

    if( args.isValid )
    {
        if( args.infile == nullptr )
        {
            args.isValid = false;
        }
    }

    return args;

}

