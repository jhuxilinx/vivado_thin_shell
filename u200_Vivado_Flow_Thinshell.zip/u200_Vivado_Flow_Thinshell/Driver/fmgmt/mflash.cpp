/**
 * Copyright (C) 2016-2018 Xilinx, Inc
 * Author(s) : Sonal Santan
 *           : Hem Neema
 *           : Ryan Radjabi
 *
 * Copyright (C) 2020 Xilinx, Inc
 * Author(s) : Jiashuai Zhang
 *           : Xiaopeng Song
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may
 * not use this file except in compliance with the License. A copy of the
 * License is located at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */


#include <sys/mman.h>
#include <stddef.h>
#include <fcntl.h>
#include <unistd.h>
#include <cassert>
#include "common.h"
#include "mflash.h"

extern "C"{
#include<pci/pci.h>
}

mflash::mflash(const char *f)
{
    mXspi = nullptr;
    mFd = 0;

    if( !mapDevice( f ) )
    {
        std::cout << "Failed to map pcie device." << std::endl;
    }
    mType = SPI;    
    switch( mType )
    {
    case SPI:
        mXspi = new flash_spi(  mMgmtMap );
        break;
    default:
        break;
    }
}

mflash::~mflash()
{
    if( mXspi != nullptr )
    {
        std::cout << "flash_spi delete" << std::endl;// Debug message remove later
        delete mXspi;
        mXspi = nullptr;
    }

    if( mMgmtMap != nullptr )
    {
        std::cout << "munmap." << std::endl;// Debug message remove later
        munmap( mMgmtMap, mSb.st_size );
    }

    if( mFd > 0 )
    {
        close( mFd );
    }
}

int mflash::upgradeFirmware(const char *f1, const char *f2)
{
    int retVal = -1;
    mType = SPI;
	
    switch( mType )
    {
    case SPI:
        if( f2 == nullptr )
        {
            retVal = mXspi->xclUpgradeFirmwareXSpi( f1 );
        }
        else
        {
            retVal = mXspi->xclUpgradeFirmware2( f1, f2 );
        }
        break;
    default:
        std::cout << "ERROR: Invalid programming type." << std::endl;
        retVal = -1;
        break;
    }
    return retVal;
}

bool mflash::mapDevice(const char *f)
{
    bool retVal = false;
    struct pci_access * x_pci_access;
    struct pci_dev * x_dev;

    std::string mgmtDeviceName = f; 
    std::cout << "mgmtDevice Name " << mgmtDeviceName << std::endl;
    std::string resourcePath;
    void *p;
    void *addr = (caddr_t)0;

    std::string devPath = "/sys/bus/pci/devices/" + mgmtDeviceName;

   resourcePath= devPath + "/resource0";
    mFd = open( resourcePath.c_str(), O_RDWR );
    
    if( mFd > 0 ) {
        if( fstat( mFd, &mSb ) != -1 )
        {
            p = mmap( addr, mSb.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, mFd, 0 );
            if( p == MAP_FAILED )
            {
                std::cout << "mmap failed : " << errno << std::endl;
                perror( "mmap" );
                close( mFd );
            }
            else
            {
                mMgmtMap = (char *)p;
                retVal = true;
            }
        }
    }
    else
    {
        std::cout << "open sysfs failed\n";
    }

/*enable PCI_COMMAND_MASTER, which is disable by default in U200 shells*/
    x_pci_access = pci_alloc();
	pci_init(x_pci_access);
	x_dev = pci_get_dev(x_pci_access, 0, 4, 0, 0);
    pci_write_byte(x_dev, 0x4, PCI_COMMAND_MASTER | PCI_COMMAND_MEMORY);
	
    usleep(1);

	pci_free_dev(x_dev);
	pci_cleanup(x_pci_access);
/*end of enabling PCI_COMMAND_MASTER*/
	
    return retVal;
}

int mflash::flashRead(unsigned int pf_bar, unsigned long long offset, void* buffer, unsigned long long length)
{
    return pcieBarRead( pf_bar, ( offset + FLASH_BASE_ADDRESS ), buffer, length );
}

int mflash::flashWrite(unsigned int pf_bar, unsigned long long offset, const void* buffer, unsigned long long length)
{
    return pcieBarWrite( pf_bar, (offset + FLASH_BASE_ADDRESS ), buffer, length );
}
 
